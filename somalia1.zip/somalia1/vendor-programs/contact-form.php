<?php 
if(isset($_REQUEST['submit'])){
    $to = "shivafeb17@gmail.com"; // this is your Email address
    $from = $_REQUEST['contactemail']; // this is the sender's Email address
    $contactname = $_REQUEST['contactname'];
    $contactphone = $_REQUEST['contactphone'];
    $contactsubject = $_REQUEST['contactsubject'];
    $subject = "Form submission";
    $subject2 = "Copy of your form submission";
    $message = $contactname . " " . $contactphone . " wrote the following:" . "\n\n" . $_POST['message'];
    $message2 = "Here is a copy of your message " . $contactname . "\n\n" . $_POST['message'];

    $headers = "From:" . $from;
    $headers2 = "From:" . $to;
    mail($to,$subject,$message,$headers);
    mail($from,$subject2,$message2,$headers2); // sends a copy of the message to the sender
    echo "Mail Sent. Thank you " . $contactname . ", we will contact you shortly.";
    // You can also use header('Location: thank_you.php'); to redirect to another page.
    }

    echo "Your information submitted successfully";
?>