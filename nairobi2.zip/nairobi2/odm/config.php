<?php


DEFINE ('DB_USER', 'iihtcom_leadmgt');
DEFINE ('DB_PASSWORD','lead@iiht123');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'iihtcom_leadmgt');



// Make the connnection and then select the database.
$dbc = @mysql_connect (DB_HOST, DB_USER, DB_PASSWORD) OR die ('Could not connect to MySQL: ' . mysql_error() );
mysql_select_db (DB_NAME) OR die ('Could not select the database: ' . mysql_error() );

// contact form mail detailas---------

DEFINE ('SEND_CONTACT_MAIL','1'); //SET 1 to  SEND CONTACT mail  

//DEFINE ('CONTACT_TO','interest@iiht.com,lakshman@iiht.com');// 

DEFINE ('CONTACT_TO','interest@iiht.com,lakshman@iiht.com,kirthana@odigma.com,santhosh@odigma.com,kumar@odigma.com'); //

 //MULTIPLE EMAIL COMMA SEPERATED  


DEFINE ('CONTACT_CC','');         //MULTIPLE EMAIL COMMA SEPERATED
DEFINE ('CONTACT_BCC','kailas.kharad@infibeam.net,kelvin.kunjukutty@infibeam.net');       //MULTIPLE EMAIL COMMA SEPERATED  

DEFINE ('CONTACT_SUBJECT','Lead details for IIHT');   

DEFINE ('SEND_OTP','0'); //SET 1 to  SEND otp 

?>
