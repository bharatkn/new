<?php

include 'config.php';

  
 if(isset($_POST['name'])){

      insertEnquiryDetails($_POST);

      fnSendMail($_POST);
      fnThankSendMail($_POST);
    
      header('location:http://iiht.com/student/interest/fb/Thank_you_page.html');   
 }else{

      header('location:index.php?valid=2');
  

 } 

function fnSendMail($post){

  $headers = "From:IIHT Leads"."\r\n";
  $headers .='Content-type: text/html; charset=iso-8859-1; format=flowed\n';
  $headers .="MIME-Version: 1.0\n";
  $headers .="Content-Transfer-Encoding: 8bit\n";
  $headers .="X-Mailer: PHP\n"; 
  $headers .= "Cc: " .CONTACT_CC. " \r\n";
  $headers .= "Bcc: ".CONTACT_BCC." \r\n";

  // Mail it
    $message='<html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>'.CONTACT_SUBJECT.'</title>
  </head>
  <body>
    <p>Hi,<br/>
    Please find below lead details for IIHT</p>
    <table>';
   if(isset($post['name'])){
       $message .='<tr>
          <td>Name</td><td>:</td><td>'.$post['name'].'</td>
      </tr>';
    }   
     if(isset($post['phone'])){
       $message .='<tr>
          <td>Phone No.</td><td>:</td><td>'.$post['phone'].'</td>
      </tr>';
    }  

    if(isset($post['email'])){
       $message .='<tr>
          <td>Email</td><td>:</td><td>'.$post['email'].'</td>
      </tr>';
    }  


    if(isset($post['location'])){
       $message .='<tr>
          <td>Location</td><td>:</td><td>'.$post['location'].'</td>
      </tr>';
    }  

    if(isset($post['technology'])){
       $message .='<tr>
          <td>Technology</td><td>:</td><td>'.$post['technology'].'</td>
      </tr>';
    }  

    
    if(isset($post['user_state'])){
       $message .='<tr>
          <td>State</td><td>:</td><td>'.fngetstateName($post['user_state']).'</td>
      </tr>';
    }  

     if(isset($post['user_city'])){
       $message .='<tr>
          <td>City</td><td>:</td><td>'.fngetcityName($post['user_city']).'</td>
      </tr>';
    }  

     if(isset($post['center'])){
       $message .='<tr>
          <td>Center</td><td>:</td><td>'.fngetcenterName($post['center']).'</td>
      </tr>';
    }  


    $message .='<tr>
          <td>Date Time</td><td>:</td><td>'.date('d/m/20y h:i:s').'</td>
      </tr>';

    if(isset($post['pageUrl'])){
     $message .='<tr>
            <td>Url</td><td>:</td><td>'.$post['pageUrl'].'</td>
      </tr>';
   }          
      
  $message .='</table></body>
  </html>
  ';
 // echo CONTACT_TO.$message;
   mail(CONTACT_TO,CONTACT_SUBJECT,$message, $headers);



}





function fnThankSendMail($post){

  $headers = "From:IIHT <leads@iiht.com>"."\r\n";
  $headers .='Content-type: text/html; charset=iso-8859-1; format=flowed\n';
  $headers .="MIME-Version: 1.0\n";
  $headers .="Content-Transfer-Encoding: 8bit\n";
  $headers .="X-Mailer: PHP\n"; 
  $headers .= "Cc: " . " \r\n";
  $headers .= "Bcc: ".CONTACT_BCC." \r\n";

  // Mail it
    $message='<html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>'.CONTACT_SUBJECT.'</title>
  </head>
  <body>
    <p>Hi '.$post['name'].',<br/>
    
<p>
Thank you for contacting IIHT with your request. We appreciate your interest in our Institute. Your enquiry request has been submitted to our counselor and you will receive a call shortly.
You can also visit our website www.iiht.com for more information.
We look forward to speaking to you soon.</p>
   

 <br/>
 Warm Regards,
 Team IIHT

  </html>
  ';
  //echo CONTACT_TO.$message;exit;
  mail($post['email'],'Thank you for contacting IIHT',$message, $headers);



}







function insertEnquiryDetails($post){


  $name           =isset($post['name'])?addslashes($post['name']):'';
  $phone          =isset($post['phone'])?addslashes($post['phone']):'';
  $Email          =isset($post['email'])?addslashes($post['email']):'';
   $location          =isset($post['location'])?addslashes($post['location']):'';

  $technology          =isset($post['technology'])?addslashes($post['technology']):'';

  $user_state          =fngetstateName($post['user_state']);//isset($post['user_state'])?addslashes($post['user_state']):'';
  $user_city           =fngetcityName($post['user_city']);//isset($post['user_city'])?addslashes($post['user_city']):'';
  $center              =fngetcenterName($post['center']);//isset($post['center'])?addslashes($post['center']):'';



    

    
    
  
  $ip=get_client_ip();

  $Source   =isset($post['utm_source'])?addslashes($post['utm_source']):'';
  $Medium   =isset($post['utm_medium'])?addslashes($post['utm_medium']):'';
  $Term     =isset($post['utm_term'])?addslashes($post['utm_term']):'';
  $Campaign =isset($post['utm_campaign'])?addslashes($post['utm_campaign']):'';
  $Content  =isset($post['utm_content'])?addslashes($post['utm_content']):'';
  $Gclid    =isset($post['utm_gclid'])?addslashes($post['utm_gclid']):'';
  

  $type='iiht';


    mysql_query("INSERT INTO `enquiryDetails` 
         set 
    
    `name`='$name',     
    `email_id`='$Email', 
    `phone`='$phone',
    `type`='$type',

    `Source`  ='$Source',
    `Medium`  ='$Medium',
    `Term`    ='$Term',
    `Campaign`='$Campaign',
    `Content` ='$Content',
    `Gclid`   ='$Gclid',

    `created_date`=NOW(),
    `modified_date`=NOW(),
    `ip`='$ip',
    `location`=' $location',
    `technology`='$technology',
    `state`='$user_state',
    `city`='$user_city',
    `center`='$center'

  
    ");

}





// Function to get the client IP address
function get_client_ip() {
    $ipaddress = '';  
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}





function fngetstateName($id){
   $query="SELECT statename FROM state where id='$id'";
   $result=mysql_query($query);  

   $row=mysql_fetch_array($result);

   return $row['statename'];

}

function fngetcityName($id){
   $query="SELECT city FROM city where id='$id'";
   $result=mysql_query($query);  

   $row=mysql_fetch_array($result);

   return $row['city'];

}



function fngetcenterName($id){
   $query="SELECT center FROM center where id='$id'";
   $result=mysql_query($query);  

   $row=mysql_fetch_array($result);

   return $row['center'];

}
?>
