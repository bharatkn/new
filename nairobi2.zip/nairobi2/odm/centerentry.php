<?php
include 'config.php';


if(isset($_REQUEST['submit'])){

$user_city=$_POST['user_city'];
$user_state=$_POST['user_state'];

$center=$_POST['center'];


$query="INSERT INTO `center` (`center`,`cityid`,`stateid`) VALUES ('$center','$user_city','$user_state');";
$result=mysql_query($query);	


}

?>





<?php


$query="SELECT id,statename FROM state";
		$result=mysql_query($query);	


?>
		
<form method="post">


&nbsp;&nbsp;&nbsp;&nbsp;<select id='user_state' name='user_state' style="  height: 28px;
  width: 283px;
  margin-top: 14px;
  background-repeat: no-repeat;
  margin-left: -65px;
font-family: 'CentraleSans-XBold';
  color: gray;
    padding-left: 8px;
  background-image: url(images/Location.png);background-position: 95%;">

  <option selected="selected" value="">Select state</option>


<?php while($row=mysql_fetch_array($result)) { ?>
<option value=<?php echo $row['id']?>><?php echo $row['statename']?></option>
<?php } ?>
</select>





<?php


$query="SELECT *  FROM city";
    $result=mysql_query($query);  


?>

<select id='user_city' name='user_city' style="  height: 28px;
  width: 283px;
  margin-top: 14px;
  background-repeat: no-repeat;
  margin-left: -65px;
font-family: 'CentraleSans-XBold';
  color: gray;
    padding-left: 8px;
  background-image: url(images/Location.png);background-position: 95%;">

  <option selected="selected" value="">Select city</option>


<?php while($row=mysql_fetch_array($result)) { ?>
<option value=<?php echo $row['id']?>><?php echo $row['city']?></option>
<?php } ?>
</select>


<input type="text" name="center">
<br>
<input type="submit" name="submit" value="submit">

</form>


