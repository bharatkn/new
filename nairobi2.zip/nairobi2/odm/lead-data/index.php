<?php
session_start();

$_SESSION['islogin']=isset($_SESSION['islogin'])  ? $_SESSION['islogin']:0;

if($_SERVER['REQUEST_METHOD']=='POST'){
    
    if($_POST['username']=='admin' && $_POST['password']=='iiht'){
        $_SESSION['islogin']=1;
    }else{
        echo '<script type="text/javascript">alert("Invalid login");</script>';
    }

}

include 'connection.php';

//export csv--------------
if(isset($_GET['csv'])){


     $sql="SELECT *,left(created_date,10) as createddate FROM `enquiryDetails`";

    $result=mysql_query($sql);

    $total_count=mysql_num_rows($result);
    
    
    if($total_count==0 || $total_count==""){
        echo '<script type="text/javascript">alert("No Record found");window.location.href ="leadTracking-list.php";</script>';exit;
    }

    require 'php-export-data.class.php';

    $exporter = new ExportDataCSV('browser', 'TrackingList.csv');
    $exporter->initialize(); // starts streaming data to web browser

    $exporter->addRow(array(

                'Name',
                'Email',
                'Phone Number',
                'state',
                'city',
                'center',
                 'ip',
                'Source',

                'Medium',
                'Term',
                'Campaign',
               
                'Gclid',
                'created date',
               
            ));

    
   while ($row = mysql_fetch_assoc($result)) {

        $exporter->addRow(array(

                    $row['name'],
                    $row['email_id'],
                    $row['phone'],
                  
                    $row['state'],
                    $row['city'],
                    $row['center'],

                 
                    $row['ip'],
                    $row['Source'],
                    
                    $row['Medium'],
                    $row['Term'],
                    $row['Campaign'],

                    $row['Gclid'],
                    $row['created_date']

                   

            ));
    }

    $exporter->finalize(); // writes the footer, flushes remaining data to browser.

    exit(); // all done

}


?>
<!DOCTYPE html>
<html>
<head>
<?php if($_SESSION['islogin']==1){  ?>

    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.5/css/jquery.dataTables.css">
    <script type="text/javascript" src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="//cdn.datatables.net/1.10.5/js/jquery.dataTables.min.js"></script>    
        
    <script type="text/javascript">

     /*   $(document).ready(function() {
            $('#tblist').dataTable( {
                "processing": true,
                "serverSide": true,
                "ajax": "ajaxfunction.php?type=1"
            } );
    } );*/


     $(document).ready(function() {
            $('#tblist').dataTable( {
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": "ajaxfunction.php",
                    "type": "POST"
                }
            } );
        } );


    </script>

<?php } ?>

 <link rel="stylesheet" type="text/css" href="login.css">

</head>
<body>


<?php  if($_SESSION['islogin']==1){  ?>

<h1 style="font-size:14px;" >Track History</h1>

<table  id="tblist" style=" border: 1px solid #c7d0d2;font-size: 12px;"   cellpadding="10" >
     <thead>

  <tr  bgcolor="#1BB78F" style="color:#fff">
   
    <th >Name</th>
    <th>Email</th>
    <th>Phone Number</th>

     <th >State</th>
    <th>City</th>
    <th>Centers</th>
  
    <th>IpAddress</th>
    <th>Source</th>
    <!--th>Gclid</th-->
    <th>Medium</th>
    <th>Term</th>
    <th>Campaign</th>

    <th>Gclid</th> 
    <th>created date</th>   
        
  </tr>
   <thead>
</table>
 </div>

 <div style="float:right"><br/><a href="index.php?csv=1">Export To CSV </a> </div>

<?php }?>


<?php if($_SESSION['islogin']==0){  ?>

<div id="container">
                <form action="" method="post">
                    <label for="loginmsg" style="color:hsla(0,100%,50%,0.5); font-family:"Helvetica Neue",Helvetica,sans-serif;"><?php  echo @$_GET['msg'];?></label>
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password">
                    <div id="lower">
                        
                        <input type="submit" name="submit" value="Login">
                    </div><!--/ lower-->
                </form>
 </div><!--/ container-->

<?php } ?>

</body>
</html>

