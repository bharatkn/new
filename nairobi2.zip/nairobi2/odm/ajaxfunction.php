<?php 

include 'config.php'; 




if(isset($_GET['op'])){

if($_GET['op']==1){

		$query="SELECT id,statename FROM state";
		$result=mysql_query($query);	


?>
		
<select id='user_state' name='user_state' onclick='javascript:getcity();' style="  height: 28px;
  width: 283px;
  margin-top: 14px;
  background-repeat: no-repeat;
  margin-left: -65px;
font-family: 'CentraleSans-XBold';
  color: gray;
    padding-left: 8px;
  background-image: url(images/Location.png);background-position: 95%;">

  <option selected="selected" value="">Select state</option>


<?php while($row=mysql_fetch_array($result)) { ?>
<option value=<?php echo $row['id']?>><?php echo $row['statename']?></option>
<?php } ?>
</select>


<?php } // end op 1?>








<?php
 if($_GET['op']==2){


	$stateid= isset($_GET['stateid'])?addslashes($_GET['stateid']):'';

	$query="SELECT id,city FROM city where stateid='".$stateid."'";
		$result=mysql_query($query);	


?>


             <select id='user_city' name='user_city'  onclick='javascript:getcenter();' style="  height: 28px;
  width: 283px;
  margin-top: 14px;
  background-repeat: no-repeat;
  margin-left: -65px;
font-family: 'CentraleSans-XBold';
  color: gray;
    padding-left: 8px;
  background-image: url(images/Location.png);background-position: 95%;">
<option selected="selected" value="">Select city</option>



<?php while($row=mysql_fetch_array($result)) { ?>
<option value=<?php echo $row['id']?>><?php echo $row['city']?></option>
<?php } ?>
</select>



<?php } // end op 2?>







<?php
 if($_GET['op']==3){


	$stateid= isset($_GET['stateid'])?addslashes($_GET['stateid']):'';
	$cityid= isset($_GET['cityid'])?addslashes($_GET['cityid']):'';

	$query="SELECT id,center FROM center where stateid='".$stateid."' and cityid='".$cityid."'" ;
		$result=mysql_query($query);	


?>



 <select name="center" id="center" style="  height: 28px;
  width: 283px;
  margin-top: 14px;
  background-repeat: no-repeat;
  margin-left: -65px;
font-family: 'CentraleSans-XBold';
  color: gray;
    padding-left: 8px;
  background-image: url(images/Location.png);background-position: 95%;">



<option selected="selected" value="" >Select Center</option>




<?php while($row=mysql_fetch_array($result)) { ?>
<option value=<?php echo $row['id']?>><?php echo $row['center']?></option>
<?php } ?>
</select>



<?php } // end op 3?>



<?php }//end op ?>






