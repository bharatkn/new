<?php
include 'config.php';


if(isset($_REQUEST['submit'])){

$city=$_POST['city'];
$user_state=$_POST['user_state'];

 $query="INSERT INTO `city` (`city`, `stateid`) VALUES ('$city','$user_state');";
$result=mysql_query($query);	


}

?>





<?php


$query="SELECT id,statename FROM state";
		$result=mysql_query($query);	


?>
		
<form method="post">


<select id='user_state' name='user_state' style="  height: 28px;
  width: 283px;
  margin-top: 14px;
  background-repeat: no-repeat;
  margin-left: -65px;
font-family: 'CentraleSans-XBold';
  color: gray;
    padding-left: 8px;
  background-image: url(images/Location.png);background-position: 95%;">

  <option selected="selected" value="">Select state</option>


<?php while($row=mysql_fetch_array($result)) { ?>
<option value=<?php echo $row['id']?>><?php echo $row['statename']?></option>
<?php } ?>
</select>

<input type="text" name="city">
<br>
<input type="submit" name="submit" value="submit">

</form>


