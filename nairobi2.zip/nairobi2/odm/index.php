<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Training Institute in Uganda | IIHT Uganda</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css"/>
  <script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script type="text/javascript" src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
 
  <script src="js/jquery.bxslider.js"></script>
 <link href="js/jquery.bxslider.css" rel="stylesheet" />
   <link href="css/lumos.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet">


  <style>


#bubble_tooltip{
width:210px;
position:absolute;
display: none;
}
#bubble_tooltip .bubble_top{
position:relative;
background-image: url(htooltip/bubble_top.gif);
background-repeat:no-repeat;
height:18px;
}
#bubble_tooltip .bubble_middle{
position:relative;
background-image: url(htooltip/bubble_middle.gif);
background-repeat: repeat-y;
background-position: bottom left;
}
#bubble_tooltip .bubble_middle div{
padding-left: 12px;
padding-right: 20px;
position:relative;
font-size: 11px;
font-family: arial, verdana, san-serif;
text-decoration: none;
color: red;
text-align:justify;
}
#bubble_tooltip .bubble_bottom{
background-image: url(htooltip/bubble_bottom.gif);
background-repeat:no-repeat;
height:65px;
position:relative;
top: 0px;
}


@font-face {
    font-family: 'CentraleSans-Regular';
    src: url('fonts/CentraleSans-Regular/CentraleSans-Regular.eot');
    src: url('fonts/CentraleSans-Regular/CentraleSans-Regular.eot') format('embedded-opentype'),
         url('fonts/CentraleSans-Regular/CentraleSans-Regular.woff') format('woff'),
         url('fonts/CentraleSans-Regular/CentraleSans-Regular.ttf') format('truetype'),
         url('fonts/CentraleSans-Regular/CentraleSans-Regular.svg#Typedepot - CentraleSans-Regular') format('svg');
}
@font-face {
    font-family: 'CentraleSans-XBold';
    src: url('fonts/CentraleSans-XBold/CentraleSans-XBold.eot');
    src: url('fonts/CentraleSans-XBold/CentraleSans-XBold.eot') format('embedded-opentype'),
         url('fonts/CentraleSans-XBold/CentraleSans-XBold.woff') format('woff'),
         url('fonts/CentraleSans-XBold/CentraleSans-XBold.ttf') format('truetype'),
         url('fonts/CentraleSans-XBold/CentraleSans-XBold.svg#Typedepot - CentraleSans-XBold') format('svg');
}
</style>  





<script type="text/javascript">

 function ValidateContactForm()
    {
        var name = document.getElementById("name");

      
        
        var email      = document.feedbackform.email;
        var phone      = document.feedbackform.phone; 
        var technology =document.feedbackform.technology;
        var user_state =document.feedbackform.user_state;
        var user_city  =document.feedbackform.user_city;
        var center     =document.feedbackform.center;

       
       if (name.value == "" || name.value =='NAME')
        {
            window.alert("Please enter your name.");
            name.focus();
            return false;
        }
        
         
        
        if (phone.value == "" || name.value =='PHONE')
        {
            window.alert("Please enter your Phone no.");
            phone.focus();
            return false;
        }

        if(isNaN(phone.value))
        {
            alert("Enter the valid Mobile Number");
            phone.focus();
            return false;
        }
        if(phone.value.length !=10)
        {

            alert(" Your Mobile Number must be 1 to 10 Integers");
            phone.focus();
            return false;
        }
        if (email.value == "" || name.value =='EMAIL')
        {
            window.alert("Please enter your Email.");
            email.focus();
            return false;
        }
        if (email.value.indexOf("@", 0) < 0)
        {
            window.alert("Please enter a valid Email address.");
            email.focus();
            return false;
        }
        if (email.value.indexOf(".", 0) < 0)
        {
            window.alert("Please enter a valid Email address.");
            email.focus();
            return false;
        }

        if (technology.value == "" )
        {
            window.alert("Please Select Technology.");
            technology.focus();
            return false;
        }
        if (user_state.value == "" )
        {
            window.alert("Please Select State.");
            user_state.focus();
            return false;
        }
        if (user_city.value == "" )
        {
            window.alert("Please Select City.");
            user_city.focus();
            return false;
        }

        if (center.value == "" )
        {
            window.alert("Please Select Center.");
            center.focus();
            return false;
        }

        return true;
    }

 function fnsubmitfrm(){
        

        if(ValidateContactForm()){
           
            document.getElementById("sidebarfeedback").submit();
           
        
    }


 }

//-------------------------

function getXMLHTTP(){

      if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }

    return  xmlhttp;
}



function getstate() {  
  var strURL="ajaxfunction.php?op=1";
  var req = getXMLHTTP();
  
  if (req) {
   req.onreadystatechange = function() {
    if (req.readyState == 4) {
     // only if "OK"
     if (req.status == 200) {     


      document.getElementById('stateli').innerHTML=req.responseText;   


     } else {
      alert("Problem while using XMLHTTP:\n" + req.statusText);
     }
    }    
   }   
   req.open("GET", strURL, true);
   req.send(null);
  }
    
 }




function getcity() {  

 var stateid=document.getElementById('user_state').value;

  var strURL="ajaxfunction.php?op=2&stateid="+stateid;
  var req = getXMLHTTP();
  
  if (req) {
   req.onreadystatechange = function() {
    if (req.readyState == 4) {
     // only if "OK"
     if (req.status == 200) {     


      document.getElementById('cityli').innerHTML=req.responseText;   


     } else {
      alert("Problem while using XMLHTTP:\n" + req.statusText);
     }
    }    
   }   
   req.open("GET", strURL, true);
   req.send(null);
  }
    
 }






function getcenter() {  

 var stateid=document.getElementById('user_state').value;
 var cityid=document.getElementById('user_city').value;


  var strURL="ajaxfunction.php?op=3&stateid="+stateid+"&cityid="+cityid;
  var req = getXMLHTTP();
  
  if (req) {
   req.onreadystatechange = function() {
    if (req.readyState == 4) {
     // only if "OK"
     if (req.status == 200) {     


      document.getElementById('centerli').innerHTML=req.responseText;   


     } else {
      alert("Problem while using XMLHTTP:\n" + req.statusText);
     }
    }    
   }   
   req.open("GET", strURL, true);
   req.send(null);
  }
    
 }


</script>


<?php if(isset($_GET['valid'])){ if($_GET['valid']==2){ 


?>
<script type="text/javascript"> alert('All fields are required.');</script>
<?php }} ?>



<script type='text/javascript' > 
(function () { 
var p5 = document.createElement('script'); p5.type = 'text/javascript'; 
p5.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 's.plumb5.com/Script1/iiht_com_1210.js'; 
var p5s = document.getElementsByTagName('script')[0]; p5s.parentNode.insertBefore(p5, p5s); 
})(); 
</script>
<script type='text/javascript' > 
(function () { 
var p5cap = document.createElement('script'); p5cap.type = 'text/javascript'; 
p5cap.src = ('https:' == document.location.protocol ? 'https://www.' : 'http://www.') + 'plumb5.com/ChatScript/Chat26112014174517-1210.js'; 
var p5scap = document.getElementsByTagName('script')[0]; p5scap.parentNode.insertBefore(p5cap, p5scap); 
})(); 
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-58559002-1', 'auto');
  ga('send', 'pageview');

</script>
</head>

<body>
    <div class="container" style="clear:both;">
<div class="row" style="background-color:#2a5e86;">
<img src="images/logo.png" style="float:left;  padding-top: 10px;
  padding-left: 9px;
  padding-bottom: 7px;">
</div>

<div class="container-fluid">

      <div class="row">
      <div class="bxslider">
  <img src="images/banner1.jpg" class="img-responsive">
</ul>

</div>
</div>
<div class="row col-sm-12">
  
  
  <div>
  
  <h1>Get In Touch Here</h1><br>
       <form data-toggle="validator" role="form" action="thankyoupage.php" method="post">
                        

                <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your Name *" id="name" name="name" required data-validation-required-message="Please enter your name.">
                        <p class="help-block text-danger"></p>
                </div>
                <div class="form-group">
                        <input type="email" class="form-control" placeholder="Your Email *" id="email" name="email" required data-validation-required-message="Please enter your email address.">
                        <p class="help-block text-danger"></p>
                </div>
                <div class="form-group">
                        <input type="tel" class="form-control" placeholder="Your Phone *" id="phone" name="phone" required data-validation-required-message="Please enter your phone number.">
                        <p class="help-block text-danger"></p>
                </div>
                <div class="form-group">
                        <textarea class="form-control" placeholder="Course Name *" id="qualification" name="qualification" required data-validation-required-message="Please enter your qualification"></textarea>
                        <p class="help-block text-danger"></p>
                </div>
                <div class="form-group">
                        <textarea class="form-control" placeholder="Your Message *" id="message1" name="message1" required data-validation-required-message="Please enter a message."></textarea>
                        <p class="help-block text-danger"></p>
                </div>
                <div id="success"></div>
                    <button type="submit" class="btn btn-xl">Send Message</button>
                   
                   </form>

</div>
</div>


<div class="container">
<div class="row"  style="text-align:center;background-image:url(images/about_bg.png);"">
<p style="font-family: 'CentraleSans-XBold';font-size: 27px;color:#f68080;padding-top: 9px;">About IIHT</p>
<p style="font-size: 21px; font-family: 'CentraleSans-Regular';">IIHT is Asia's leading IT professional training solution providers. Established in the year 1993, it<br>

provides services in hardware & networking, database management, security & storage<br>

management services.<span style="color:#2a5e86;font-family: 'CentraleSans-XBold';"> We are highly celebrated for<br> our training capabilities for many leading software products and technology platforms.</span></p>
</div>
</div>

<div class="container">
<div class="row"  style="text-align:center;">
<h3  style="font-family: 'CentraleSans-XBold';font-size: 27px;color:#2a5e86;padding-top: 9px;  padding-bottom: 15px;">A glance at the technologies</h3>
</div>
<div class="row"  style="text-align:center;">
 <a href="#CloudComputing" class="cources"><img id="bnt1" src="images/btn_1.png"></a>
 <a href="#softwaredeveloper" class="cources"><img id="bnt2" src="images/btn_2.png"></a>
</div>
<div class="row"  style="text-align:center;  margin-top: -68px;">
 <a href="#BScITIMS" class="cources"><img id="bnt3" src="images/btn_3.png"></a>
 <a href="#MobilityAndroid" class="cources"><img id="bnt4" src="images/btn_4.png"></a>
 <a href="#Hadoop" class="cources"><img id="bnt5" src="images/btn_5.png"></a>
</div>
</div>

<div class="row"  style="float:right;">
 <a href="#myDiv" class="various"><img src="images/placement_portal.png" style="width: 59px;
  margin-top: -999%;"></a>
</div>


<div class="container">
<div class="row" style="text-align:center;">
<h3  style="font-family: 'CentraleSans-XBold';font-size: 27px;color:#2a5e86;padding-top: 9px;">Key Highlights</h3>
</div>
<div class="row" style="float:left;">
<div class="col-lg-12">
<ul style="  font-size: 17px; line-height: 45px;font-family: 'CentraleSans-XBold';color:#2a5e86;margin-left: 94px;">
<li>Top­notch industry experienced faculty</li>

<li>Certified Lab infrastructure, easy<br>access to internet</li>

<li>Job­oriented training solutions</li>

<li>More employability meeting the industry standards</li>

<li>Over 95% placement every year</li>
</ul>
</div>
</div>
<div class="row" style="float:right;">
<div class="col-lg-12">
<ul style="  font-size: 17px;  line-height: 45px;font-family: 'CentraleSans-XBold';color:#2a5e86;">
<li>Personality Development</li>

<li>Diverse learning and talent development<br> programs</li>

<li>Tailor made course curriculum for working professionals</li>

<li>Zonal placement cells to make job <br>search easy</li>
</ul>

</div>
</div>
</div>
<div class="container">
<div class="row" style="text-align:center;background-image:url(images/bottom_bg.png);margin-top: -79px;">
<p style="padding-top: 309px;font-family: 'CentraleSans-XBold';font-size: 27px;color:#f68080;">Why IIHT?</p>
<p style="font-size: 21px; font-family: 'CentraleSans-Regular';color:white;">A pioneer in IT training and development, IIHT prepares students for their dream job by honing

their IT & Professional skills. With strategically designed job specific curriculum and best industry

experts, IIHT provides a truly learning­rich experience. We provide 360' career guidance with

unique learning methodology, state­of­the­art infrastructure and industry driven curriculum.</p>
</div>
</div>

<div class="container">
<div class="row" style="text-align:center;">
<p style="color:#2a5e86;font-family: 'CentraleSans-XBold';font-size: 27px;padding-top: 9px;">prospective Employers</p>
<img src="images/Brand_logos.png" class="img-responsive">
</div>
</div>
<div class="container">
<div class="row" style="text-align:center;">
<p style=" font-family: 'CentraleSans-Regular';font-size: 16px;background-color:#f68080;color:black;padding-top:2px;padding-bottom:2px;">Copyright @ 2015 IIHT. All Rights Reserved.</p>
</div>
</div>




</div>




<link rel="stylesheet" href="fancybox/source/jquery.fancybox.css" type="text/css" media="screen" />
<script type="text/javascript" src="fancybox/source/jquery.fancybox.pack.js"></script>





<p>
    <div style="display:none">
      <div id="myDiv">
               
          <img src="images/placement_portal_screenshot.png" class="img-responsive">
          <a href="http://placement.iiht.com"><img src="images/know_more_btn.jpg" class="img-responsive" style="margin-top:-150px;padding-left:20px"></a> 

      </div>
    </div>
    
 </p>



<p>
    <div style="display:none">
      <div id="CloudComputing">



        <h2>JOB OPPORTUNITIES ON COURSE COMPLETION</h2><br>

        <!--h3>Cloud Computing</h3><br-->
        
        <!--p class="pop-hd"><strong>Key Features:</strong></p>

            <ul class="pop-ul">
              
              <li> 80 hours of learning.</li>
               <li>Prepare for 70-246, 70-247 exam.</li>
                <li>One-on-one instruction attention</li>
               <li>Hands-on labs</li>
              <li> Highly experienced faculties who have worked on domain extensively.</li>
               <li>Course completion certificate.</li>


              
            </ul>
         </p>   
           
        <p class="pop-hd"><strong>Benefits and Advantages:</strong></p>
          <ul class="pop-ul">
             <li>As more companies adopt public, private and hybrid cloud, the need for trained admins is in rapid increase</li>
              <li>Few trending job profiles in the industry for this certification are developer, architect,data analyst, security guru.</li>
              <li>Just as cloud computing is still evolving, so too are the career opportunities.</li>


         
          </ul>
        
        </p-->  


        <!--p class="pop-hd"> <strong>Jobs and Positions:</strong></p-->
        <ul class="pop-ul">
             <li>Cloud Solution Architect</li>
              <li>Data Analyst</li>
              <li>IT Specialist – Cloud</li>
              <li>DevOps Engineer</li>
              <li>System Admin – Cloud</li>

        </ul>
     

        </p>

      </div>
    </div>
    
 </p>




<p>
    <div style="display:none">
      <div id="Hadoop">



        <h2>JOB OPPORTUNITIES ON COURSE COMPLETION</h2><br>

        <!--h3>Hadoop</h3><br-->
        
        <!--p class="pop-hd"><strong>Key Features:</strong></p>

            <ul class="pop-ul">
                              
                <li>80 hours of learning.</li>
                <li>Prepare for Cloudera Hadoop Developer Certification. RHCSS/RHCE is for Linux</li>
                <li>One-on-one instruction attention</li>
                <li>Hands-on labs</li>
                <li>Highly experienced faculties who have worked on domain extensively.</li>
                <li>Course completion certificate.</li>
              
            </ul>
        </p>    
           
        <!--p class="pop-hd"><strong>Benefits and Advantages:</strong></p>
          <ul class="pop-ul">
             


              <li>It provides Distributed storage & Computational capabilities both</li>
              <li>It is scalable, it was the first considered to fix a scalability issue which existed in Nutch like the open source crawler and search engine systems</li>
              <li>Here HDFS the storage component is optimised for high throughput</li>
              <li>HDFS works best when executing large files like gigabytes, petabytes</li>
              <li>Scalability, Availability are the features of HDFS</li>
              <li>It achieves data replication & fault tolerance system</li>
              <li>MapReduce framework is a batch based computing framework</li>
              <li>It enables paralleled task over a big amount of data</li>
                       
          </ul>
        
        </p-->


        <!--p class="pop-hd"> <strong>Jobs and Positions:</strong></p-->
        <ul class="pop-ul">
            

            <li>Software Engineer – Hadoop</li>
            <li>Hadoop Administrator</li>
            <li>Testing Engineer – Hadoop</li>
            <li>Technical Lead – Hadoop</li>

        </ul>
     
        </p>

      </div>
    </div>
    
 </p>





<p>
    <div style="display:none">
      <div id="BScITIMS">



        <h2>JOB OPPORTUNITIES ON COURSE COMPLETION</h2><br>

        <!--h3>B.Sc IT IMS</h3><br-->
        
        <!--p class="pop-hd"><strong>Key Features:</strong></p>

            <ul class="pop-ul">
                              
                <li>3 years degree course from Sikkim Manipal University.</li>
                <li>Learning with hands on experience.</li>
                <li>This help you develop practical knowledge in the high end devices of lab. Trainees are guided by the experienced teachers in this particular field to impart the excellence skills in troubleshooting problems.</li>
                <li>Highly experienced faculties who have worked on computer extensively.</li>
               <li> Learn multiple technologies which are popular and in demand.</li>
               <li> Course completion certificate.</li>
              
            </ul>
         </p>   
           
        <!--p class="pop-hd"><strong>Benefits and Advantages:</strong></p>
          <ul class="pop-ul">
             
             <li> Provides complete overview of virtualization techniques</li>
              <li>Establishes cloud expertise in the global market</li>
              <li>A degree that gives you job before you finish the training</li>
              <li>Offers greater career opportunities</li>
             <li> Enhances knowledge on IMS technologies</li>
             <li> Improves job performance</li>


              
          </ul>
        
        </p-->


        <!--p class="pop-hd"> <strong>Jobs and Positions:</strong></p-->
        <ul class="pop-ul">
            
            <li>Cloud Engineer</li>
            <li>Cloud Architect</li>
            <li>Backup Engineer</li>
            <li>Linux Admin</li>
            <li>Virtualization Engineer (Hyper V)</li>
            <li>Virtualization Engineer (VMware)</li>
            <li>Virtualization Engineer (XenServer)</li>
            <li>Server Admin</li>
            <li>System Administrator (Monitoring)</li>

         

        </ul>
     
        </p>

      </div>
    </div>
    
 </p>






<p>
    <div style="display:none">
      <div id="MobilityAndroid">



        <h2>JOB OPPORTUNITIES ON COURSE COMPLETION</h2><br>

        <!--h3>Mobility & Android</h3><br-->
        
        <!--p class="pop-hd"><strong>Key Features:</strong></p>

            <ul class="pop-ul">
                              
               
                <li>Learning with hands on experience.</li>
                <li>Highly experienced faculties who have worked on computer extensively.</li>
                <li>Deep dive in technology along with project work.</li>
               <li> Course completion certificate.</li>


              
            </ul>
       </p-->     
           
        <!--p class="pop-hd"><strong>Benefits and Advantages:</strong></p>
          <ul class="pop-ul">
             
           <li>Creation of GUI applications with use of JAVA would be much easier than before. One of the striking reasons contributing towards this feature is that it is all based on JAVA.</li>
          <li>Data centric applications can be created with use of SQL and JAVA.</li>
          <li>JSP/Servlets, Struts Frameworks can be used to create Web Based Applications.</li>
          <li>Creation of mobile applications with use of Android. If you have the need to create a specific application which can be used for Android Operating Systems, then yes this course enables you to complete your creativity.</li>
          <li>SDLC artifacts can be created by use of high-end software.</li>


              
          </ul>
        
        </p-->


        <!--p class="pop-hd"> <strong>Jobs and Positions:</strong></p-->
        <ul class="pop-ul">
            
            <li>Developer</li>
           <li>Technical Architect (.Android)</li>
          <li> Sr. Developer</li>
           <li>Software Engineer</li>
           <li>Sr. Software Engineer</li>
           <li>Project manager</li>

         

        </ul>
     
        </p>

      </div>
    </div>
    
 </p>





<p>
    <div style="display:none">
      <div id="softwaredeveloper">



        <h2>JOB OPPORTUNITIES ON COURSE COMPLETION</h2><br>

        <!--h3>softwaredeveloper</h3><br-->
        
       


        <!--p class="pop-hd"> <strong>Jobs and Positions:</strong></p-->
        <ul class="pop-ul">
                          
              <li>Developer</li>
              <li>Technical Architect</li>
              <li>Sr. Developer</li>
              <li>Software Engineer</li>
              <li>Sr. Software Engineer</li>
              <li>Project manager</li>
         

        </ul>
     
        </p>

      </div>
    </div>
    
 </p>





<script type="text/javascript">

$(document).ready(function(){
    
  $(".fancybox").fancybox({
    openEffect  : 'none',
    closeEffect : 'none',
    iframe : {
      preload: false
    }
  });
  
  
  
  $(".various").fancybox({
    maxWidth  : 1136,
    maxHeight : 800,
    fitToView : false,
    width   : '70%',
    height    : '70%',
    autoSize  : false,
    closeClick  : false,
    openEffect  : 'none',
    closeEffect : 'none',
    scrolling   : 'no'
  });
  
  
  $(".cources").fancybox({
    maxWidth  : 900,
    maxHeight : 700,
    fitToView : false,
    width   : '60%',
    height    : '400',
    autoSize  : false,
    closeClick  : false,
    openEffect  : 'none',
    closeEffect : 'none',
     scrolling   : 'no'
   
  });
  
});

getstate();





$("#bnt1").mouseover(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt1").animate({width: "300px"}, 'slow');
}); 



$("#bnt1").mouseout(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt1").animate({width: "256px"},'slow');
}); 




$("#bnt2").mouseover(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt2").animate({width: "300px"}, 'slow');
}); 



$("#bnt2").mouseout(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt2").animate({width: "256px"},'slow');
}); 



$("#bnt3").mouseover(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt3").animate({width: "300px"}, 'slow');
}); 



$("#bnt3").mouseout(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt3").animate({width: "256px"},'slow');
}); 




$("#bnt4").mouseover(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt4").animate({width: "300px"}, 'slow');
}); 



$("#bnt4").mouseout(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt4").animate({width: "256px"},'slow');
}); 



$("#bnt5").mouseover(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt5").animate({width: "300px"}, 'slow');
}); 



$("#bnt5").mouseout(function(){
    //$("#bnt1").attr("src", "");
    $("#bnt5").animate({width: "256px"},'slow');
}); 


</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-58559002-1', 'auto');
  ga('send', 'pageview');

</script>
<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 953472134;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/953472134/?value=0&amp;guid=ON&amp;script=0"/>
</div>
</noscript>


</body>
</html>
