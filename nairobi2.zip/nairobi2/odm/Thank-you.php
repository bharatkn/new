
	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>


</head>

<body>
<div id="main">

	    <div class="container" style="clear:both;">

<div class="row" style="background-color:#2a5e86;">
<img src="images/logo.png" style="float:left;  padding-top: 10px;
  padding-left: 9px;
  padding-bottom: 7px;">
</div>

<div class="container-fluid">

      <div class="row">
      <div class="bxslider">
  <img src="images/banner.jpg" class="img-responsive">
</ul>

</div>
</div>
				
		
		
	</div>

	<div id="part" align="center" style="padding-top:15px;color:green">
		Thank you for contacting IIHT, We will get in touch shortly.</br></br>

		 </div>

</div>
<br/><br/><br/><br/>

<!-- Google Code for Landing Page Lead 1 Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 953472134;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "xW3KCL7Eil8QhqnTxgM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/953472134/?label=xW3KCL7Eil8QhqnTxgM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>


</body>
</html>
